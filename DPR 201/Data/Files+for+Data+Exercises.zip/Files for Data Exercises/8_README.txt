The data was kindly provided by Gilles Gignac and Marcin Zajenkiwski and
is publicly available at osf.io/dg547.

id is an id number for each invidual subject

study indicates the particular study from which the data was drawn

(You probably won't need either the id or the study variable to
complete the exercise.)

selfiq is each subject's self-assessed IQ score

testiq is each subject's test-assessed IQ score