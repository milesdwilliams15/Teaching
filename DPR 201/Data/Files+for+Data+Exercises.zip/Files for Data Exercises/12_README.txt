The file "ChicagoCrimeTemperature2018.csv" contains data on temperature
and crime in Chicago for each day of 2018.

Each row of the data set is a day of the year 2018.

Summary of variables:
temp: the average temperature on that day (in degrees Fahrenheit) as
measured at Midway Airport

crimes: the total number of crimes reported on that day in the city
of Chicago

